from multiprocessing import context
from urllib import request
from django.http import HttpResponse
from django.shortcuts import render


def home(request):
    if request.method == 'POST':
        color_name = request.POST['color'] 
        text_name = request.POST['color2']
        context = {'color':color_name ,'color2':text_name }
        return render(request, 'index.html',context)
    return render (request, 'index.html')
