from django.apps import AppConfig


class ColorChangeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'color_change'
